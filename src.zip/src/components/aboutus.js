import React,{Component} from 'react';
export default class Aboutus extends Component{
    render(){
        return(
            <div>
            <p>About us</p>
            </div>
    
    )
    }
}
