import React, { Component } from "react";
import "./selectt.css";
import { BrowserRouter, Route, Link } from "react-router-dom";

export default class SelectT extends Component {
  render() {
    return (
      <div>
        <h1 className="Class1"> Step 1</h1>
        <Link to="/survey">THIS WILL BE REPLACED WITH TEMP1 SS </Link>
      </div>
    );
  }
}
