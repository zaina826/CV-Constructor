import React,{Component} from 'react';
import '../Main.css'
export default class Error extends Component{
    render(){
        return(
            <div>
            <h1 >Error</h1>
            </div>
    
    )
    }
}
