import React ,{Component} from 'react'
export default class Survey4 extends Component {
    render() {
         return (
              <div>
              survey4
              </div>
         );
    }
}